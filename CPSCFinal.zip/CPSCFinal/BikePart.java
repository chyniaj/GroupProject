/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cpscproject;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;
import java.util.Collections;
import java.util.Iterator;
/**
 *
 * @author kerri
 */
public class BikePart implements Comparable<BikePart>, Iterator<BikePart>{
    private String partName;
    private int partNum;
    private double listPrice;
    private double salePrice;
    private boolean onSale;
    private int quantity;

    /**
     * Constructor for objects of class BikePart
     */
    public BikePart(String partName, int partNum, double listPrice,double salePrice, boolean onSale,int quantity)
    {
        this.partName = partName;
        this.partNum = partNum;
        this.listPrice = listPrice;
        this.salePrice = salePrice;
        this.onSale = onSale;
        this.quantity = quantity;
    }

    public String getPartName()
    {
        return this.partName;
    }

    public int getPartNum()
    {
        return this.partNum;
    }

    public double getListPrice(){
        return this.listPrice;
    }

    public double getSalePrice(){
        return this.salePrice;
    }

    public boolean getSaleStatus(){
        return this.onSale;
    }

    public int getQuantity(){
        return this.quantity;
    }

    public void setPartName(String partName){
        this.partName = partName;
    }

    public void setPartNum(int partNum){
        this.partNum = partNum;
    }

    public void setListPrice(double listPrice){
        this.listPrice = listPrice;
    }

    public void setSalePrice(double salePrice){
        this.salePrice = salePrice;
    }

    public void setSaleStatus(boolean onSale){
        this.onSale = onSale;
    }

    public void setQuantity(int quantity){
        this.quantity=quantity;
    }

    public void printInfo(){
        System.out.println(partName+","+partNum+","+listPrice+","+salePrice+","+onSale+","+quantity);
    }
    
    public int compareTo(BikePart p) {
        return this.partName.compareToIgnoreCase(p.partName);
    }

    @Override
    public boolean hasNext() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public BikePart next() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cpscproject;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kerri
 */
public class BikePartTest {
    
    public BikePartTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getPartName method, of class BikePart.
     */
    @Test
    public void testGetPartName() {
        System.out.println("getPartName");
        BikePart instance = new BikePart("Spoke",1234567890,34.0,23.0,true,3);
        String expResult = "Spoke";
        String result = instance.getPartName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPartNum method, of class BikePart.
     */
    @Test
    public void testGetPartNum() {
        System.out.println("getPartNum");
        BikePart instance = new BikePart("Spoke",1234567890,34.0,23.0,true,3);
        int expResult = 1234567890;
        int result = instance.getPartNum();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getListPrice method, of class BikePart.
     */
    @Test
    public void testGetListPrice() {
        System.out.println("getListPrice");
        BikePart instance = new BikePart("Spoke",1234567890,34.0,23.0,true,3);
        double expResult = 34.0;
        double result = instance.getListPrice();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getSalePrice method, of class BikePart.
     */
    @Test
    public void testGetSalePrice() {
        System.out.println("getSalePrice");
        BikePart instance = new BikePart("Spoke",1234567890,34.0,23.0,true,3);
        double expResult = 23.0;
        double result = instance.getSalePrice();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getSaleStatus method, of class BikePart.
     */
    @Test
    public void testGetSaleStatus() {
        System.out.println("getSaleStatus");
        BikePart instance = new BikePart("Spoke",1234567890,34.0,23.0,true,3);
        boolean expResult = true;
        boolean result = instance.getSaleStatus();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getQuantity method, of class BikePart.
     */
    @Test
    public void testGetQuantity() {
        System.out.println("getQuantity");
        BikePart instance = new BikePart("Spoke",1234567890,34.0,23.0,true,3);
        int expResult = 3;
        int result = instance.getQuantity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}

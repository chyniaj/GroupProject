/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cpscproject;
import java.util.Comparator;
/**
 *
 * @author kerri
 */
public class ComparatorByPartNumber implements Comparator<BikePart>{
   @Override 
   public int compare(BikePart num1, BikePart num2) {
       if(num1.getPartNum() < (num2.getPartNum())) {
           return -1;
        }
       if(num1.getPartNum() > (num2.getPartNum())) {
           return 1;
        }
        return 0;
    }
}

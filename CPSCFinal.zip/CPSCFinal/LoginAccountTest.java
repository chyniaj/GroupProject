/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cpscproject;

import static com.mycompany.cpscproject.LoginAccount.hashPassword;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kerri
 */
public class LoginAccountTest {
    
    public LoginAccountTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getUsername method, of class LoginAccount.
     */
    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        LoginAccount instance = new LoginAccount("testing123", "testtest");
        String expResult = "testing123";
        String result = instance.getUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPassword method, of class LoginAccount.
     */
    @Test
    public void testGetPassword() {
        System.out.println("getPassword");
        LoginAccount instance = new LoginAccount("testing123", "testtest");
        byte[] expResult = instance.getPassword();
        byte[] result = instance.getPassword();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getPasswordHolder method, of class LoginAccount.
     */
    @Test
    public void testGetPasswordHolder() {
        System.out.println("getPasswordHolder");
        LoginAccount instance = new LoginAccount("testing123","testtest");
        String expResult = "testtest";
        String result = instance.getPasswordHolder();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of logIn method, of class LoginAccount.
     */
    @Test
    public void testLogIn() {
        System.out.println("logIn");
        String userName = "admin";
        String Password = "nimda";
        LoginAccount instance = new LoginAccount("admin", "nimda");
        String expResult = "true";
        String result = instance.logIn(userName, Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}

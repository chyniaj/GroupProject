import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;
/**
 * Write a description of class Van here.
 *
 * @author Kerri, Chy and Lewis
 * @version 10/23/19
 */
public class Van
{
    
    private ArrayList<BikePart> inventory = new ArrayList<BikePart>();
    private ArrayList<BikePart> warehouse = new ArrayList<BikePart>();
    private String vanName;

    /**
     * Constructor for objects of class Van
     */
    public Van(String vanName)
    {
        inventory = new ArrayList<BikePart>();
        warehouse = new ArrayList<BikePart>();
        this.vanName = vanName.trim();
        readVanInventory(inventory, vanName);
        readVanWarehouse(warehouse,vanName);
        this.inventory = inventory;
        this.warehouse = warehouse;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public ArrayList<BikePart> getWarehouse()
    {
        return this.warehouse;
    }

    public ArrayList<BikePart> getInventory()
    {
        return this.inventory;
    } 
    
    public String getVanName(){
        return this.vanName;
    }

    public static void readVanWarehouse(ArrayList<BikePart> warehouse, String vanName)
    {
        try{
            String partName;
            int partNum;
            double listPrice;
            double salePrice;
            boolean saleStatus;
            int quantity;
            FileInputStream fileIn = new FileInputStream(vanName+".txt");
            Scanner scanIn = new Scanner(fileIn);

            while(scanIn.hasNextLine()){
                String info = scanIn.nextLine();
                info = info.trim();
                String[] infoHolder = info.split(",");
                partName = infoHolder[0];
                partNum = Integer.parseInt(infoHolder[1]);
                listPrice = Double.parseDouble(infoHolder[2]);
                salePrice = Double.parseDouble(infoHolder[3]);
                saleStatus = Boolean.parseBoolean(infoHolder[4]);
                quantity = Integer.parseInt(infoHolder[5]);
                BikePart part = new BikePart(partName, partNum, listPrice, salePrice, saleStatus, quantity);
                warehouse.add(part);
            }
            fileIn.close();
        }
        catch (FileNotFoundException e){
            System.out.println("File Not Found. Please restart and enter new file name.");
            e.printStackTrace();
        }
        catch (IOException e){
            System.out.print("IOException. Please restart.");
            e.printStackTrace();
        }
        
    }
    
    public static void readVanInventory(ArrayList<BikePart> inventory, String vanName){
        try{
            String partName;
            int partNum;
            double listPrice;
            double salePrice;
            boolean saleStatus;
            int quantity;
            FileInputStream fileIn = new FileInputStream(vanName+".txt");
            Scanner scanIn = new Scanner(fileIn);

            while(scanIn.hasNextLine()){
                String info = scanIn.nextLine();
                info = info.trim();
                String[] infoHolder = info.split(",");
                partName = infoHolder[0];
                partNum = Integer.parseInt(infoHolder[1]);
                listPrice = Double.parseDouble(infoHolder[2]);
                salePrice = Double.parseDouble(infoHolder[3]);
                saleStatus = Boolean.parseBoolean(infoHolder[4]);
                quantity = Integer.parseInt(infoHolder[5]);
                BikePart part = new BikePart(partName, partNum, listPrice, salePrice, saleStatus, quantity);
                inventory.add(part);
            }
            fileIn.close();
        }
        catch (FileNotFoundException e){
            System.out.println("File Not Found. Please restart and enter new file name.");
            e.printStackTrace();
        }
        catch (IOException e){
            System.out.print("IOException. Please restart.");
            e.printStackTrace();
        }
    }
    
    public static void printOutVanWarehouse(Van v) throws FileNotFoundException, IOException{
        FileOutputStream fileOut = new FileOutputStream(v.getVanName()+".txt");
        PrintWriter out = new PrintWriter(fileOut);
        for(int i = 0; i < v.getWarehouse().size(); i++){
            out.println(v.getWarehouse().get(i).getPartName()+","+v.getWarehouse().get(i).getPartNum()+","+v.getWarehouse().get(i).getListPrice()+","+v.getWarehouse().get(i).getSalePrice()+","+v.getWarehouse().get(i).getSaleStatus()+","
                +v.getWarehouse().get(i).getQuantity());
        }
        out.flush();
        fileOut.close();
        
    }
}

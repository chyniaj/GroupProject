import java.util.Comparator;
/**
 * Write a description of class ComparatorByPartNumber here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class ComparatorByPartNumber implements Comparator<BikePart> {
    @Override
    public int compare(BikePart num1, BikePart num2) {

       if(num1.getPartNum() < (num2.getPartNum())) {
           return -1;
        }
       if(num1.getPartNum() > (num2.getPartNum())) {
           return 1;
        }
        return 0;
    }
} 
